import React, { useState } from 'react';
import { Search, Plus, X } from 'lucide-react';

const SAMPLE_CATEGORIES: IngredientCategory[] = [
  {
    name: 'Proteins',
    ingredients: [
      { id: '1', name: 'Chicken', category: 'Proteins' },
      { id: '2', name: 'Eggs', category: 'Proteins' },
      { id: '3', name: 'Beef', category: 'Proteins' },
    ]
  },
  {
    name: 'Vegetables',
    ingredients: [
      { id: '4', name: 'Tomatoes', category: 'Vegetables' },
      { id: '5', name: 'Onions', category: 'Vegetables' },
      { id: '6', name: 'Bell Peppers', category: 'Vegetables' },
    ]
  },
  {
    name: 'Grains',
    ingredients: [
      { id: '7', name: 'Rice', category: 'Grains' },
      { id: '8', name: 'Pasta', category: 'Grains' },
      { id: '9', name: 'Bread', category: 'Grains' },
    ]
  }
];

interface IngredientSelectorProps {
  onSearch: (ingredients: string[]) => void;
}

export function IngredientSelector({ onSearch }: IngredientSelectorProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedIngredients, setSelectedIngredients] = useState<Ingredient[]>([]);
  const [activeCategory, setActiveCategory] = useState<string>(SAMPLE_CATEGORIES[0].name);

  const handleIngredientSelect = (ingredient: Ingredient) => {
    if (!selectedIngredients.find(i => i.id === ingredient.id)) {
      const newSelected = [...selectedIngredients, ingredient];
      setSelectedIngredients(newSelected);
      onSearch(newSelected.map(i => i.name));
    }
  };

  const handleIngredientRemove = (ingredientId: string) => {
    const newSelected = selectedIngredients.filter(i => i.id !== ingredientId);
    setSelectedIngredients(newSelected);
    onSearch(newSelected.map(i => i.name));
  };

  const filteredIngredients = activeCategory
    ? SAMPLE_CATEGORIES.find(c => c.name === activeCategory)?.ingredients.filter(
        i => i.name.toLowerCase().includes(searchTerm.toLowerCase())
      ) || []
    : [];

  return (
    <div className="flex gap-6">
      {/* Selected Ingredients */}
      <div className="w-1/3 bg-white rounded-xl shadow-lg p-6">
        <h3 className="text-lg font-semibold mb-4">My Ingredients</h3>
        <div className="space-y-2">
          {selectedIngredients.map(ingredient => (
            <div
              key={ingredient.id}
              className="flex items-center justify-between bg-gray-50 px-4 py-2 rounded-lg"
            >
              <span>{ingredient.name}</span>
              <button
                onClick={() => handleIngredientRemove(ingredient.id)}
                className="text-gray-400 hover:text-red-500"
              >
                <X size={18} />
              </button>
            </div>
          ))}
          {selectedIngredients.length === 0 && (
            <p className="text-gray-500 text-sm">No ingredients selected</p>
          )}
        </div>
      </div>

      {/* Ingredient Selector */}
      <div className="flex-1 bg-white rounded-xl shadow-lg p-6">
        <div className="mb-6">
          <div className="relative">
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search ingredients..."
              className="w-full px-4 py-2 pl-10 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-emerald-200"
            />
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
          </div>
        </div>

        <div className="flex gap-4 mb-6 overflow-x-auto pb-2">
          {SAMPLE_CATEGORIES.map(category => (
            <button
              key={category.name}
              onClick={() => setActiveCategory(category.name)}
              className={`px-4 py-2 rounded-full whitespace-nowrap ${
                activeCategory === category.name
                  ? 'bg-emerald-500 text-white'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              {category.name}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-2 gap-2">
          {filteredIngredients.map(ingredient => (
            <button
              key={ingredient.id}
              onClick={() => handleIngredientSelect(ingredient)}
              disabled={selectedIngredients.some(i => i.id === ingredient.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-left transition-colors ${
                selectedIngredients.some(i => i.id === ingredient.id)
                  ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                  : 'bg-gray-50 hover:bg-emerald-50 text-gray-700 hover:text-emerald-600'
              }`}
            >
              <Plus size={18} className="flex-shrink-0" />
              <span>{ingredient.name}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}