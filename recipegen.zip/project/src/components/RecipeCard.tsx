import React from 'react';
import { Clock, Users } from 'lucide-react';
import type { Recipe } from '../types';

interface RecipeCardProps {
  recipe: Recipe;
}

export function RecipeCard({ recipe }: RecipeCardProps) {
  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden transition-transform hover:scale-[1.02]">
      <div className="relative h-48 overflow-hidden">
        <img
          src={recipe.image || 'https://images.unsplash.com/photo-1495521821757-a1efb6729352?q=80&w=800'}
          alt={recipe.name}
          className="w-full h-full object-cover"
        />
      </div>
      <div className="p-6">
        <h3 className="text-xl font-semibold mb-2">{recipe.name}</h3>
        <div className="flex items-center gap-4 text-gray-600 mb-4">
          <div className="flex items-center gap-1">
            <Clock size={16} />
            <span className="text-sm">{recipe.prepTime + recipe.cookTime} mins</span>
          </div>
          <div className="flex items-center gap-1">
            <Users size={16} />
            <span className="text-sm">{recipe.servings} servings</span>
          </div>
        </div>
        <div className="space-y-4">
          <div>
            <h4 className="font-medium mb-2">Ingredients:</h4>
            <ul className="list-disc list-inside text-gray-600 text-sm">
              {recipe.ingredients.slice(0, 3).map((ingredient, index) => (
                <li key={index}>{ingredient}</li>
              ))}
              {recipe.ingredients.length > 3 && (
                <li className="list-none text-emerald-600">+{recipe.ingredients.length - 3} more</li>
              )}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}