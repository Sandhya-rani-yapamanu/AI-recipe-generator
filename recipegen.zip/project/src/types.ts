export interface Recipe {
  id: string;
  name: string;
  ingredients: string[];
  instructions: string[];
  prepTime: string;
  cookTime: string;
  servings: number;
  image?: string;
}

export interface Ingredient {
  id: string;
  name: string;
  category: string;
}

export interface IngredientCategory {
  name: string;
  ingredients: Ingredient[];
}

export interface SearchFilters {
  query: string;
  ingredients: string[];
}