import React, { useState } from 'react';
import { ChefHat, Camera } from 'lucide-react';
import { SearchBar } from './components/SearchBar';
import { ImageUpload } from './components/ImageUpload';
import { RecipeCard } from './components/RecipeCard';
import { IngredientSelector } from './components/IngredientSelector';
import type { Recipe } from './types';
import toast, { Toaster } from 'react-hot-toast';

function App() {
  const [searchMethod, setSearchMethod] = useState<'text' | 'ingredients' | 'image'>('ingredients');
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [loading, setLoading] = useState(false);

  const handleSearch = async (query: string) => {
    setLoading(true);
    try {
      const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/generate-recipe`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ ingredients: [query] }),
      });

      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Failed to generate recipe');
      }

      setRecipes([data]);
      toast.success('Recipe generated!');
    } catch (error) {
      console.error('Recipe generation error:', error);
      toast.error(error.message || 'Failed to generate recipe');
    } finally {
      setLoading(false);
    }
  };

  const handleIngredientSearch = async (ingredients: string[]) => {
    if (ingredients.length === 0) {
      setRecipes([]);
      return;
    }
    
    setLoading(true);
    try {
      const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/generate-recipe`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ ingredients }),
      });

      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Failed to generate recipe');
      }

      setRecipes([data]);
      toast.success(`Recipe generated using ${ingredients.length} ingredients!`);
    } catch (error) {
      console.error('Recipe generation error:', error);
      toast.error(error.message || 'Failed to generate recipe');
    } finally {
      setLoading(false);
    }
  };

  const handleImageUpload = async (file: File) => {
    setLoading(true);
    try {
      // First, upload the image and analyze it
      const formData = new FormData();
      formData.append('image', file);
      
      // TODO: Implement image analysis endpoint
      const ingredients = ['pasta', 'tomatoes']; // This will come from image analysis
      
      // Then, generate a recipe with the detected ingredients
      await handleIngredientSearch(ingredients);
    } catch (error) {
      toast.error('Failed to analyze image');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Toaster position="top-right" />
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <ChefHat className="text-emerald-500" size={40} />
            <h1 className="text-4xl font-bold text-gray-900">Recipe Generator</h1>
          </div>
          <p className="text-gray-600 text-lg">
            Find recipes using ingredients you already have in your kitchen
          </p>
        </div>

        <div className="flex justify-center mb-8">
          <div className="flex gap-4 p-1 bg-gray-100 rounded-full">
            <button
              onClick={() => setSearchMethod('ingredients')}
              className={`px-6 py-2 rounded-full transition-colors ${
                searchMethod === 'ingredients'
                  ? 'bg-white text-emerald-600 shadow-sm'
                  : 'text-gray-600 hover:text-emerald-600'
              }`}
            >
              Select Ingredients
            </button>
            <button
              onClick={() => setSearchMethod('text')}
              className={`px-6 py-2 rounded-full transition-colors ${
                searchMethod === 'text'
                  ? 'bg-white text-emerald-600 shadow-sm'
                  : 'text-gray-600 hover:text-emerald-600'
              }`}
            >
              Search by Text
            </button>
            <button
              onClick={() => setSearchMethod('image')}
              className={`px-6 py-2 rounded-full transition-colors ${
                searchMethod === 'image'
                  ? 'bg-white text-emerald-600 shadow-sm'
                  : 'text-gray-600 hover:text-emerald-600'
              }`}
            >
              <div className="flex items-center gap-2">
                <Camera size={20} />
                Upload Image
              </div>
            </button>
          </div>
        </div>

        <div className="mb-12">
          {searchMethod === 'ingredients' ? (
            <IngredientSelector onSearch={handleIngredientSearch} />
          ) : searchMethod === 'text' ? (
            <div className="flex justify-center">
              <SearchBar onSearch={handleSearch} />
            </div>
          ) : (
            <div className="max-w-xl mx-auto">
              <ImageUpload onImageUpload={handleImageUpload} />
            </div>
          )}
        </div>

        {loading ? (
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-500 mx-auto"></div>
            <p className="text-gray-600 mt-4">Generating recipe for you...</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {recipes.map((recipe) => (
              <RecipeCard key={recipe.id} recipe={recipe} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default App;