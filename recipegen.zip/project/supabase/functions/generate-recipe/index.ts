import { createClient } from 'npm:@supabase/supabase-js@2.39.7';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
};

interface RequestBody {
  ingredients: string[];
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { ingredients } = await req.json() as RequestBody;

    if (!ingredients || ingredients.length === 0) {
      return new Response(
        JSON.stringify({ error: 'No ingredients provided' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const OPENAI_API_KEY = Deno.env.get('OPENAI_API_KEY');
    if (!OPENAI_API_KEY) {
      throw new Error('OpenAI API key is not configured');
    }

    // Create the prompt for recipe generation
    const prompt = `Create a recipe using these ingredients: ${ingredients.join(', ')}. 
    Format the response as a JSON object with the following structure:
    {
      "name": "Recipe Name",
      "ingredients": ["list", "of", "ingredients", "with", "quantities"],
      "instructions": ["step 1", "step 2", "etc"],
      "prepTime": "time in minutes",
      "cookTime": "time in minutes",
      "servings": number
    }`;

    // Initialize OpenAI client using Supabase AI
    const aiResponse = await fetch(
      'https://api.openai.com/v1/chat/completions',
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${OPENAI_API_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'gpt-3.5-turbo',
          messages: [{ role: 'user', content: prompt }],
          temperature: 0.7,
        }),
      }
    );

    if (!aiResponse.ok) {
      const errorData = await aiResponse.json().catch(() => ({}));
      throw new Error(`OpenAI API error: ${errorData.error?.message || aiResponse.statusText}`);
    }

    const completion = await aiResponse.json();
    
    if (!completion.choices?.[0]?.message?.content) {
      throw new Error('Invalid response format from OpenAI API');
    }

    let recipe;
    try {
      recipe = JSON.parse(completion.choices[0].message.content);
    } catch (parseError) {
      throw new Error('Failed to parse recipe data from OpenAI response');
    }

    // Add a relevant image from Unsplash
    const UNSPLASH_ACCESS_KEY = Deno.env.get('UNSPLASH_ACCESS_KEY');
    if (UNSPLASH_ACCESS_KEY) {
      try {
        const unsplashResponse = await fetch(
          `https://api.unsplash.com/search/photos?query=${encodeURIComponent(recipe.name)}&client_id=${UNSPLASH_ACCESS_KEY}`
        );

        if (unsplashResponse.ok) {
          const unsplashData = await unsplashResponse.json();
          if (unsplashData.results.length > 0) {
            recipe.image = unsplashData.results[0].urls.regular;
          }
        } else {
          console.error('Unsplash API error:', await unsplashResponse.text());
        }
      } catch (unsplashError) {
        console.error('Error fetching Unsplash image:', unsplashError);
        // Don't throw here - we can still return the recipe without an image
      }
    }

    return new Response(
      JSON.stringify(recipe),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in generate-recipe function:', error);
    return new Response(
      JSON.stringify({ 
        error: error.message || 'Failed to generate recipe',
        details: error.stack
      }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});